package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.style.ClickableSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Primeiro#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Primeiro extends Fragment {
    EditText hi;
    EditText mi;
    EditText hf;
    EditText mf;
    TextView resulth;
    int hri;
    int hrf;
    int mini;
    int minf;
    Button rmv;
    Button add;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Primeiro() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Primeiro.
     */
    // TODO: Rename and change types and number of parameters
    public static Primeiro newInstance(String param1, String param2) {
        Primeiro fragment = new Primeiro();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_primeiro, container, false);
        add = v.findViewById(R.id.soma);
        rmv = v.findViewById(R.id.sub);
        hi = v.findViewById(R.id.hi);
        mi = v.findViewById(R.id.mi);
        hf = v.findViewById(R.id.hf);
        mf = v.findViewById(R.id.mf);
        resulth = v.findViewById(R.id.resulth);
        hi.setText("");
        mi.setText("");
        hf.setText("");
        mf.setText("");
        rmv.setOnClickListener(click ->{
            subtrai();
        });
        add.setOnClickListener(click ->{
            soma();
        });
        return v;
    }
    public void soma() {
        pegar();
        int rh = hri + hrf;
        int rm = mini + minf;
        while (rm > 59) {
            rm = rm - 60;
            rh++;
        }
        if (rm == 0) {
            resulth.setText(rh + ":00");
        } else if (rm < 10) {
            resulth.setText(rh + ":0" + rm);
        } else {
            resulth.setText(rh + ":" + rm);
        }
    }
    public void subtrai() {
        pegar();
        int rh = 0;
        int rm = 0;
        while(hri>0){
            hri--;
            mini += 60;
        }
        while(hrf>0){
            hrf--;
            minf += 60;
        }
        if (minf > mini) {
            rm = minf - mini;
        } else {
            rm = mini - minf;
        }
        while (rm > 59) {
            rm = rm - 60;
            rh++;
        }

        if (rm == 0) {
            resulth.setText (rh + ":00");
        } else if (rm < 10 && rm > 0) {
            resulth.setText (rh + ":0" + rm);
        } else {
            resulth.setText (rh + ":" + rm);
        }
    }
    public void pegar(){
        String shri = hi.getText().toString();
        String smini = mi.getText().toString();
        String shrf = hf.getText().toString();
        String sminf = mf.getText().toString();
        if (sminf.equals("")) {
            sminf = "0";
        }
        if (smini.equals("")) {
            smini = "0";
        }
        if (shrf.equals("")) {
            shrf = "0";
        }
        if (shri.equals("")) {
            shri = "0";
        }
        hri = Integer.parseInt(shri);
        hrf = Integer.parseInt(shrf);
        mini = Integer.parseInt(smini);
        minf = Integer.parseInt(sminf);
    }
}